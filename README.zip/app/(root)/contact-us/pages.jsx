import React from 'react'

const pages = () => {
  return (
    <div>Contact</div>
  )
}

export default pages