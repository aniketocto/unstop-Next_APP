export default function Home() {
  return <h1 className="Hii "></h1>;
}
``