import React from 'react'

const page = () => {
  return (
    <div>Project</div>
  )
}

export default page