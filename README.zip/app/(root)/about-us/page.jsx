import React from "react";

const page = () => {
  return <div>about</div>;
};

export default page;
